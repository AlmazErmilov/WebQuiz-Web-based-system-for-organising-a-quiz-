from flask import Flask, render_template, request, redirect, url_for, flash
import mysql.connector

app = Flask(__name__)
app.secret_key = 'quiz'
app.config['APPLICATION_ROOT'] = '/templates'

def get_db_connection():
    connection = mysql.connector.connect(
        host='kark.uit.no',
        user='stud_v23_aer068',
        password='uitphp+69',
        database='stud_v23_aer068'
    )
    return connection

@app.route('/')
def main():
    return render_template('main.html')

@app.route('/admin')
def admin():
    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM questions")
    questions_raw = cursor.fetchall()
    questions = [dict(id=row[0], quiz_id=row[1], question_text=row[2], answer=row[3], category = row[4]) for row in questions_raw]
    cursor.close()
    connection.close()
    return render_template('admin.html', questions=questions)

@app.route('/user')
def user():
    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM quizzes")
    quizzes_raw = cursor.fetchall()
    quizzes = [dict(id=row[0], name=row[1], category=row[2]) for row in quizzes_raw]
    cursor.close()
    connection.close()
    return render_template('user.html', quizzes=quizzes)

@app.route('/edit_question/<int:question_id>', methods=['GET', 'POST'])
def edit_question(question_id):
    connection = get_db_connection()
    cursor = connection.cursor()

    if question_id == 0:
        # Create a new question
        if request.method == 'POST':
            category = request.form['category']
            question_text = request.form['question_text']
            answer = request.form['answer']
            cursor.execute("INSERT INTO questions (category, question_text, answer) VALUES (%s, %s, %s)", (category, question_text, answer))
            connection.commit()
            flash('Question created successfully')
            return redirect(url_for('admin'))
        else:
            question = {'id': 0, 'category': '', 'question_text': '', 'answer': ''}
    else:
        # Edit an existing question
        if request.method == 'POST':
            category = request.form['category']
            question_text = request.form['question_text']
            answer = request.form['answer']
            cursor.execute("UPDATE questions SET category=%s, question_text=%s, answer=%s WHERE id=%s", (category, question_text, answer, question_id))
            connection.commit()
            flash('Question updated successfully')
            return redirect(url_for('admin'))
        else:
            cursor.execute("SELECT * FROM questions WHERE id=%s", (question_id,))
            question_raw = cursor.fetchone()
            question = {'id': question_raw[0], 'category': question_raw[1], 'question_text': question_raw[2], 'answer': question_raw[3]}

    cursor.close()
    connection.close()
    return render_template('edit_question.html', question=question)

@app.route('/quiz/<int:quiz_id>', methods=['GET'])
def display_quiz(quiz_id):
    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM questions WHERE quiz_id=%s", (quiz_id,))
    questions_raw = cursor.fetchall()
    questions = [dict(id=row[0], quiz_id=row[1], question_text=row[2], answer=row[3], category = row[4]) for row in questions_raw]
    cursor.close()
    connection.close()
    return render_template('quiz.html', questions=questions)

@app.route('/submit_quiz', methods=['POST'])
def submit_quiz():
    quiz_id = request.form['quiz_id']
    user_answers = []

    for key, value in request.form.items():
        if key.startswith('answer_'):
            question_id = int(key[7:])
            user_answers.append((quiz_id, question_id, value))

    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.executemany("INSERT INTO user_answers (quiz_id, question_id, answer) VALUES (%s, %s, %s)", user_answers)
    connection.commit()
    cursor.close()
    connection.close()

    flash('Quiz submitted successfully')
    return redirect(url_for('user'))

@app.route('/quiz_results/<int:quiz_id>', methods=['GET'])
def quiz_results(quiz_id):
    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute("SELECT q.question_text, ua.answer, q.answer as correct_answer FROM questions q JOIN user_answers ua ON q.id = ua.question_id WHERE ua.quiz_id = %s", (quiz_id,))
    results_raw = cursor.fetchall()
    results = [dict(question_text=row[0], answer=row[1], correct_answer=row[2]) for row in results_raw]
    cursor.close()
    connection.close()
    return render_template('quiz_results.html', results=results)

@app.route('/delete_question/<int:question_id>', methods=['POST'])
def delete_question(question_id):
    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute("DELETE FROM questions WHERE id=%s", (question_id,))
    connection.commit()
    cursor.close()
    connection.close()
    flash('Question deleted successfully')
    return redirect(url_for('admin'))

if __name__ == '__main__':
    app.run(debug=True)
