HOST='kark.uit.no'
USER='stud_v23_aer068'
PASSWORD='uitwebdte69'
DATABASE='stud_v23_aer068'